# AURA GEMS

Luxury gemstone specimen showcase — Dubai, UAE.

## Quick Start

```bash
npx serve public
```

## Deploy to Vercel

### Option A: Via GitHub (recommended)

1. Push this repo to GitHub
2. Go to [vercel.com](https://vercel.com) → **New Project**
3. Import your GitHub repo
4. Settings will auto-detect from `vercel.json`
5. Click **Deploy**

### Option B: Via Vercel CLI

```bash
npm i -g vercel
vercel
```

## Project Structure

```
aura-gems-site/
├── public/
│   ├── index.html      ← Single-page site (all CSS/JS inlined)
│   └── img/
│       ├── citrine.jpg
│       ├── aquamarine-matrix.jpg
│       └── pink-tourmaline.jpg
├── vercel.json          ← Vercel config + caching headers
├── package.json
└── README.md
```

## Features

- Full-viewport snap-scroll sections (Instagram-style)
- 3D CSS crystal animation in hero
- Full-bleed gemstone photography with text overlays
- 5 luxury font pairings (live switcher)
- Device preview toggle (Desktop / iPad / iPhone)
- WhatsApp integration for inquiries
- Responsive design
- Performance optimized (lazy loading, GPU-composited animations)
